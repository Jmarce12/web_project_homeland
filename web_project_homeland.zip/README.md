# Tripleten web_project_homeland

Esta página nos muestra las ciudades natales de algunos empleados de TripleTen.

Con este diseño se pretende mostrar los conocimientos adquiridos sobre diseño responsivo. El diseño se realizó usando consultas de medios, y las medidas de width con porcentajes de elementos contenedores como referencia, dado que ofrecen una mejor escalabilidad al momento de cambiar el tamaño de la pantalla en la que se esté visualizando. Adicional se usó la metodología BEM y posicionamiento.

https://Jmarce12.github.io/web_project_homeland
